library("shiny")
runApp("./app/vregi/", launch.browser = TRUE)

